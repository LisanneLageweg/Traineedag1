# reprodev2024
Course collaboration for Reproducible Programming and Development

Please fork this repo and send a PR to update the list below

- Gerko Vink
  - My [Tutorial 1 / Tutorial 2 final repo](https://github.com/gerkovink/reprodev/tree/exercise_quarto_gerko) with the [link to the rendered `Quarto` document](https://www.gerkovink.com/reprodev2024/reprodev-exercise_quarto.html)
  - My [R-package on Zenodo](https://zenodo.org/records/7668889)
    

